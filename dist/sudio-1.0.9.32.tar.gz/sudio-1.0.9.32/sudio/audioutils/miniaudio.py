from _miniaudio import lib as _lib

_lib.init_miniaudio()
